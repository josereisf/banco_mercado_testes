<?php


//require_once "teste_editarCliente.php";
//require_once "teste_listarClientes.php";

    require_once "teste_deletarCliente.php";
?>