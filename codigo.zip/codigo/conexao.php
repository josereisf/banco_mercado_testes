<?php
$servidor = 'db';
$usuario = 'root';
$password = '123';
$banco = 'banco_mercado';

$conexao = mysqli_connect($servidor, $usuario, $password, $banco);